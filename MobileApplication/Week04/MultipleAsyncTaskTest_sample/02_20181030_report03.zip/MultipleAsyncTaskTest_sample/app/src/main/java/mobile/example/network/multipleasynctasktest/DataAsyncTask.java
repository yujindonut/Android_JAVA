package mobile.example.network.multipleasynctasktest;

public interface DataAsyncTask {
}
